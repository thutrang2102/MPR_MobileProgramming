package com.example.myteams;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileFragment#} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment implements View.OnClickListener {
    TextView tvname, tvemail;
    ImageView avatar;

    RestLoader restLoader;
    ImageLoader imageLoader;
    String urlText;
    String urlImage;
    int userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);


        tvname = v.findViewById(R.id.nameTv);
        tvemail = v.findViewById(R.id.emailTv);
        avatar = v.findViewById(R.id.avatar);
        ImageButton decreaseBtn = v.findViewById(R.id.btnDerease);
        ImageButton increaseBtn = v.findViewById(R.id.btnIncrease);

        decreaseBtn.setOnClickListener(this);
        increaseBtn.setOnClickListener(this);

        userId = 1;
        return v;
    }


    @Override
    public void onClick(View v) {
        RestLoader restLoader = new RestLoader();

        ImageLoader imageLoader = new ImageLoader();
            switch (v.getId()) {
                case R.id.btnDerease:
                    userId--;
                    urlText = "https://jsonplaceholder.typicode.com/users/" + userId;
                    Log.d("URLTEXT", urlText);
                    restLoader = new RestLoader();
                    restLoader.execute(urlText);
                    imageLoader = new ImageLoader();
                    imageLoader.execute(urlImage);
                    urlImage = "https://robohash.org/"+userId+"?set=set2";
                    imageLoader = new ImageLoader();
                    imageLoader.execute(urlImage);

                    break;

                case R.id.btnIncrease:
                    userId++;
                    urlText = "https://jsonplaceholder.typicode.com/users/" + userId;
                    Log.d("URLTEXT", urlText);
                    restLoader = new RestLoader();
                    restLoader.execute(urlText);

                    urlImage = "https://robohash.org/"+userId+"?set=set2";
                    imageLoader = new ImageLoader();
                    imageLoader.execute(urlImage);
                    break;

        }
    }


        public class RestLoader extends AsyncTask<String, Void, String> {
            URL url;
            HttpURLConnection urlConnection;

            @Override
            protected String doInBackground(String... strings) {
                try {
                    url = new URL(strings[0]);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();
                    InputStream is = urlConnection.getInputStream();
                    Scanner sc = new Scanner(is);
                    StringBuilder result = new StringBuilder();
                    String line;
                    while (sc.hasNextLine()) {
                        line = sc.nextLine();
                        result.append(line);
                    }
                    Log.i("RESULT",  result.toString());
                    return result.toString();
                } catch (MalformedURLException e) {
                    e.printStackTrace();

                } catch (IOException e) {
                    e.printStackTrace();

                }
                return null;
            }


            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                if (result == null) {
//                Toast.makeText(MainActivity.this, "ERROR", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    JSONObject root = new JSONObject(result);

                    String name = root.getString("name");
                    String email = root.getString("email");

                    tvname.setText(name);
                    tvemail.setText(email);

                } catch (JSONException e) {
                    e.printStackTrace();

                }


            }
        }

        public class ImageLoader extends AsyncTask<String, Void, Bitmap> {
            URL url;
            HttpURLConnection urlConnection;

            //connect to url
            @Override
            protected Bitmap doInBackground(String... strings) {
                try {
                    url = new URL(strings[0]);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();
                    InputStream is = urlConnection.getInputStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(is);
                    return bitmap;
                } catch (MalformedURLException e) {

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            //display result
            @Override
            protected void onPostExecute(Bitmap bitmap) {
                avatar.setImageBitmap(bitmap);
            }

        }
    }

