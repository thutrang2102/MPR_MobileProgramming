package com.example.hellojapan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.graphics.Color;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Button btn1, btn2;
    private  RecyclerViewAdapter HiraAdapter, KataAdapter;
    private RecyclerView.LayoutManager layoutManager;

    //        RecyclerViewAdapter recyclerViewAdapter;
    private int[] imageH = {R.drawable.b11h, R.drawable.b12h, R.drawable.b13h, R.drawable.b14h, R.drawable.b15h,
            R.drawable.b21h, R.drawable.b22h, R.drawable.b23h, R.drawable.b24h, R.drawable.b25h,
            R.drawable.b31h, R.drawable.b32h, R.drawable.b33h, R.drawable.b34h, R.drawable.b35h,
            R.drawable.b41h, R.drawable.b42h, R.drawable.b43h, R.drawable.b44h, R.drawable.b45h,
            R.drawable.b51h, R.drawable.b52h, R.drawable.b53h, R.drawable.b54h, R.drawable.b55h,
            R.drawable.b61h, R.drawable.b62h, R.drawable.b63h, R.drawable.b64h, R.drawable.b65h,
            R.drawable.b71h, R.drawable.b72h, R.drawable.b73h, R.drawable.b74h, R.drawable.b75h,
            R.drawable.b81h, R.drawable.empty, R.drawable.b83h, R.drawable.empty, R.drawable.b85h,
            R.drawable.b91h, R.drawable.b92h, R.drawable.b93h, R.drawable.b94h, R.drawable.b95h,
            R.drawable.b101h, R.drawable.empty, R.drawable.empty, R.drawable.empty, R.drawable.b105h,
            R.drawable.b102h, R.drawable.empty, R.drawable.empty, R.drawable.empty, R.drawable.empty};
    private int[] imageK = {R.drawable.b11k, R.drawable.b12k, R.drawable.b13k, R.drawable.b14k, R.drawable.b15k,
            R.drawable.b21k, R.drawable.b22k, R.drawable.b23k, R.drawable.b24k, R.drawable.b25k,
            R.drawable.b31k, R.drawable.b32k, R.drawable.b33k, R.drawable.b34k, R.drawable.b35k,
            R.drawable.b41k, R.drawable.b42k, R.drawable.b43k, R.drawable.b44k, R.drawable.b45k,
            R.drawable.b51k, R.drawable.b52k, R.drawable.b53k, R.drawable.b54k, R.drawable.b55k,
            R.drawable.b61k, R.drawable.b62k, R.drawable.b63k, R.drawable.b64k, R.drawable.b65k,
            R.drawable.b71k, R.drawable.b72k, R.drawable.b73k, R.drawable.b74k, R.drawable.b75k,
            R.drawable.b81k, R.drawable.empty, R.drawable.b83k, R.drawable.empty, R.drawable.b85k,
            R.drawable.b91h, R.drawable.b92k, R.drawable.b93k, R.drawable.b94k, R.drawable.b95k,
            R.drawable.b101k, R.drawable.empty, R.drawable.empty, R.drawable.empty, R.drawable.b105k,
            R.drawable.b201k, R.drawable.empty, R.drawable.empty, R.drawable.empty, R.drawable.empty};
    private int[] audio = {R.raw.a_akira, R.raw.i_akira, R.raw.u_akira, R.raw.e_akira, R.raw.o_akira,
            R.raw.ka_akira, R.raw.ki_akira, R.raw.ku_akira, R.raw.ke_akira, R.raw.ko_akira,
            R.raw.sa_akira, R.raw.shi_akira, R.raw.su_akira, R.raw.se_akira, R.raw.so_akira,
            R.raw.ta_akira, R.raw.ch_akira, R.raw.tsu_akira, R.raw.te_akira, R.raw.to_akira,
            R.raw.na_akira, R.raw.ni_akira, R.raw.nu_akira, R.raw.ne_akira, R.raw.no_akira,
            R.raw.ha_akira, R.raw.hi_akira, R.raw.fu_akira, R.raw.he_akira, R.raw.ho_akira,
            R.raw.ma_akira, R.raw.mi_akira, R.raw.mu_akira, R.raw.me_akira, R.raw.mo_akira,
            R.raw.ya_akira, 0, R.raw.yu_akira, 0, R.raw.yo_akira,
            R.raw.ra_akira, R.raw.ri_akira, R.raw.ru_akira, R.raw.re_akira, R.raw.ro_akira,
            R.raw.wa_akira, 0, 0, 0, R.raw.wo_akira,
            R.raw.n_akira, 0, 0, 0, 0};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new GridLayoutManager(MainActivity.this,5, GridLayoutManager.VERTICAL, false);
        HiraAdapter = new RecyclerViewAdapter(imageH, audio, MainActivity.this);
        KataAdapter = new RecyclerViewAdapter(imageK, audio, MainActivity.this);


        TextView tv = (TextView) findViewById(R.id.text1);

        // button => set to imgK
        btn1 = findViewById(R.id.button1);
        btn2 = findViewById(R.id.button2);

        btn1.setBackgroundColor(Color.BLUE);
        btn2.setBackgroundColor(Color.WHITE);

        findViewById(R.id.text2).animate().alpha(0f);
        findViewById(R.id.text1).animate().alpha(1f);
        recyclerView.setAdapter(HiraAdapter);
        HiraAdapter.setImage(imageH);
        recyclerView.setLayoutManager(layoutManager);


    }

    public void onClick(View view) {

        if (view == btn1) {
            btn1.setBackgroundColor(Color.BLUE);
            btn2.setBackgroundColor(Color.WHITE);
            findViewById(R.id.text2).animate().alpha(0f);
            findViewById(R.id.text1).animate().alpha(1f);
            findViewById(R.id.text1).animate().translationYBy(-35).setDuration(500).withEndAction(new Runnable() {
                @Override
                public void run() {

                    findViewById(R.id.text1).animate().translationYBy(35).setDuration(500);
                }
            });
            recyclerView.setAdapter(HiraAdapter);
            HiraAdapter.setImage(imageH);
            recyclerView.setLayoutManager(layoutManager);
        }
        else if (view == btn2) {
            btn2.setBackgroundColor(Color.BLUE);
            btn1.setBackgroundColor(Color.WHITE);
            findViewById(R.id.text2).animate().alpha(1f);
            findViewById(R.id.text1).animate().alpha(0f);
            findViewById(R.id.text2).animate().translationYBy(-35).setDuration(500).withEndAction(new Runnable() {
                @Override
                public void run() {

                    findViewById(R.id.text2).animate().translationYBy(35).setDuration(500);
                }
            });
            recyclerView.setAdapter(KataAdapter);
            KataAdapter.setImage(imageK);
            recyclerView.setLayoutManager(layoutManager);
        }

    }

    public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {
        int [] image;
        int [] audio;
        private Context context;

        public RecyclerViewAdapter(int[] image, int[] audio, Context context) {

            this.audio = audio;
            this.context = context;
            this.image = image;
        }

        public void setImage(int[] image) {
            this.image = image;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate( R.layout.data, parent, false);
            MyViewHolder myViewHolder = new MyViewHolder(view);
            return myViewHolder ;
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            holder.imageView.setImageResource(image[position]);

            holder.imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (audio[position] != 0){
                        MediaPlayer mediaPlayer = MediaPlayer.create(context, audio[position]);
                        mediaPlayer.start();
                    }
                }
            });
        }



        @Override
        public int getItemCount() {

            return image.length;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.imageView);

            }

        }
    }



}